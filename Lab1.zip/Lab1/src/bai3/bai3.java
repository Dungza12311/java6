package bai3;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({"/crud/create","/crud/update","/crud/delete", "/crud/edit/*"})
public class bai3  extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri = req.getRequestURI();
		resp.setContentType("text/html;charset=UTF-8");
		if(uri.contains("create")) {
			resp.getWriter().print("Bạn đang thực hiện chức năng tạo mới!");
		}else if (uri.contains("update")) {
			resp.getWriter().println("Bạn đang thực hiện chức năng cập nhật!");
		}else if (uri.contains("delete")) {
			resp.getWriter().println("Bạn đang thực hiện chức năng xóa!");
		}else {
			resp.getWriter().println("Bạn đang thực hiện chức năng edit!");
		}

	}

}

package bai4;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class bai4
 */
@WebServlet("/bai4")
public class bai4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bai4() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 // Lấy các thông tin từ request
        String url = request.getRequestURL().toString(); 
        String uri = request.getRequestURI();
        String queryString = request.getQueryString();
        String servletPath = request.getServletPath();
        String contextPath = request.getContextPath();
        String pathInfo = request.getPathInfo();
        String method = request.getMethod();

        // Xuất thông tin ra trình duyệt
        response.getWriter().append("<html><body>");
        response.getWriter().append("<h2>Thông tin URL:</h2>");
        response.getWriter().append("URL: " + url + "<br>");
        response.getWriter().append("URI: " + uri + "<br>");
        response.getWriter().append("Query String: " + (queryString != null ? queryString : "Không có") + "<br>");
        response.getWriter().append("Servlet Path: " + servletPath + "<br>");
        response.getWriter().append("Context Path: " + contextPath + "<br>");
        response.getWriter().append("Path Info: " + (pathInfo != null ? pathInfo : "Không có") + "<br>");
        response.getWriter().append("Method: " + method + "<br>");
        response.getWriter().append("</body></html>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
